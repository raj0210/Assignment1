
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author c0644689
 */
public class Order {

    private int customerId;
    private String customerName;
    private String timeReceived;
    private String timeProcessed;
    private String timeFullfilled;
    private List<Purchase> listOfPurchases;
    private String notes;

    public Order() {
    customerId = 0;
    customerName = "";
    timeReceived = "";
    timeProcessed = "";
    timeFullfilled = "";
    listOfPurchases = new ArrayList<>();
    notes = "";
}

    public Order(int customerId, String customerName, String timeReceived, String timeProcessed, String timeFullfilled, List<Purchase> listOfPurchases, String notes) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.timeReceived = timeReceived;
        this.timeProcessed = timeProcessed;
        this.timeFullfilled = timeFullfilled;
        this.listOfPurchases = listOfPurchases;
        this.notes = notes;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setTimeReceived(String timeReceived) {
        this.timeReceived = timeReceived;
    }

    public void setTimeProcessed(String timeProcessed) {
        this.timeProcessed = timeProcessed;
    }

    public void setTimeFullfilled(String timeFullfilled) {
        this.timeFullfilled = timeFullfilled;
    }

    public void setListOfPurchases(List<Purchase> listOfPurchases) {
        this.listOfPurchases = listOfPurchases;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getTimeReceived() {
        return timeReceived;
    }

    public String getTimeProcessed() {
        return timeProcessed;
    }

    public String getTimeFullfilled() {
        return timeFullfilled;
    }

    public List<Purchase> getListOfPurchases() {
        return listOfPurchases;
    }

    public String getNotes() {
        return notes;
    }
    
    

}
