
import java.util.ArrayDeque;
import java.util.Queue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author c0644689
 */
public class OrderQ {
    
    private Queue<Order> OrderQueue;

    public OrderQ() {
        this.OrderQueue = new ArrayDeque<>();
    }
    
    

    public void setOrderQueue(Queue<Order> OrderQueue) {
        this.OrderQueue = OrderQueue;
    }

    public Queue<Order> getOrderQueue() {
        return OrderQueue;
    }
    
    public void addOrder (Order order){
        this.OrderQueue.add(order);
    }
    
    public void deleteOrder (Order order){
        this.OrderQueue.remove();
    }
    
}
