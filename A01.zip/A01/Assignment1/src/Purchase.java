/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author c0644689
 */
public class Purchase {
    private int productID;
    private int quantity;

    public Purchase() {
    productID = 0;
    quantity = 0;     
    }

    public Purchase(int productID, int quantity) {
        this.productID = productID;
        this.quantity = quantity;
    }
    

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProductID() {
        return productID;
    }

    public int getQuantity() {
        return quantity;
    }
    
    
    
}
