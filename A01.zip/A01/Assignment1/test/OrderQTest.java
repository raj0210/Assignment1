/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Queue;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author c0644689
 */
public class OrderQTest {
    
    public OrderQTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setOrderQueue method, of class OrderQ.
     */
    @Test
    public void testSetOrderQueue() {
        System.out.println("setOrderQueue");
        Queue<Order> OrderQueue = null;
        OrderQ instance = new OrderQ();
        instance.setOrderQueue(OrderQueue);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOrderQueue method, of class OrderQ.
     */
    @Test
    public void testGetOrderQueue() {
        System.out.println("getOrderQueue");
        OrderQ instance = new OrderQ();
        Queue<Order> expResult = null;
        Queue<Order> result = instance.getOrderQueue();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addOrder method, of class OrderQ.
     */
    @Test
    public void testAddOrder() {
        System.out.println("addOrder");
        Order order = null;
        OrderQ instance = new OrderQ();
        instance.addOrder(order);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteOrder method, of class OrderQ.
     */
    @Test
    public void testDeleteOrder() {
        System.out.println("deleteOrder");
        Order order = null;
        OrderQ instance = new OrderQ();
        instance.deleteOrder(order);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
